<?php
	echo"
	<div class=\"footer\">
			Optimator is product of Opti Technology Pty Ltd. Optimator is in early development.
	</div></body>";
?>