<?php
	include 'Design/header.php';
?>
<body>	
	<section class="content">
		<h1> Opti </h1>
		<p>This site is a work in progress. Owned by Opti Technology Pty Ltd. </p>
		<p> Current Project: Optimator </p>
		<br><br>
	</section>

	<section class="bgimg">
		<h1> Optimator </h1>
		<a href="pieces">Find out more...</a>
		<img src='Design/Images/coverbg.png' alt="Triangle in Optimator">
	</section>
	
	<?php
		include 'Design/footer.php';
	?>
</body>