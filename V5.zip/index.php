<?php
	include 'Design/header.php';
?>
<body>	
	<section class="content">
		<h1> Optimator </h1>
		<p>This site is a work in progress. Owned by Opti Technology Pty Ltd. </p>
		<br><br>
	</section>
	
	<?php
		include 'Design/footer.php';
	?>
</body>