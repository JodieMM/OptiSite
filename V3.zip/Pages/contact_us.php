<?php
	include 'Design/header.php';
?>
<body>	
	<section class="content">
		<h1> Optimator </h1>
		<p> Contact us at jodie@opti.technology for general enquiries </p>
		<br><br>
	</section>
	
	<?php
		include 'Design/footer.php';
	?>
</body>