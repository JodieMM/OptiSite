<?php
	include 'Design/header.php';
?>
<body>	
	<section class="content">
		<h1> Optimator </h1>
		<p>Terms and Conditions will go here </p>
		<br><br>
	</section>
	
	<?php
		include 'Design/footer.php';
	?>
</body>