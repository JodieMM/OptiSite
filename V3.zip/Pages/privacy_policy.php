<?php
	include 'Design/header.php';
?>
<body>	
	<section class="content">
		<h1> Optimator </h1>
		<p>Privacy Policy will go here </p>
		<p> Privacy concerns can be sent to privacy@opti.technology </p>
		<br><br>
	</section>
	
	<?php
		include 'Design/footer.php';
	?>
</body>