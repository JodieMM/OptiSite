<?php
	echo"
	<div class=\"footer\">
			Optimator is part of the Opti company. Optimator is in early development.
	</div></body>";
?>