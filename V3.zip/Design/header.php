<?php
	echo"
<html>
<head>
    <title>Optimator</title>
    <link href=\"../Design/style.css\" rel=\"stylesheet\" type=\"text/css\"/>
	<link href=\"https://fonts.googleapis.com/css?family=Dosis\" rel=\"stylesheet\">
	<link rel=\"icon\" href=\"../Design/Images/logo.png\">
	<script type=\"text/javascript\" src=\"../Functions/JSFunctions.js\"></script>
</head>
<body>
	<div class=\"header\">
		<nav>
			<ul>
				<a href=\"../index.php\"><li>Optimator</li></a>
				<a href=\"../Pages/pieces.php\"><li>Pieces</li></a>
				<div class=\"dropdown\">
					<li>Account</li>
					<div class=\"dropdown-options\">
						<a href=\"../Pages/logout.php\">Logout</a>
						<a href=\"../Pages/update.php\">Update</a>
					</div>
				</div>
			</ul>
		</nav>
	</div>";
?>